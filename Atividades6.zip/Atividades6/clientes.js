let clientes = [
    {
        nome_completo: "João Silva",
        email: "joao@example.com",
        contato: "(11) 91234-5678",
        cpf: "123.456.789-00",
        data_nascimento: "1990-05-15"
    },
    {
        nome_completo: "Maria Oliveira",
        email: "maria@example.com",
        contato: "(21) 98765-4321",
        cpf: "987.654.321-00",
        data_nascimento: "1985-10-20"
    },
    {
        nome_completo: "Carlos Souza",
        email: "carlos@example.com",
        contato: "(31) 99876-5432",
        cpf: "456.789.123-00",
        data_nascimento: "1982-03-07"
    },
    {
        nome_completo: "Ana Rodrigues",
        email: "ana@example.com",
        contato: "(11) 92345-6789",
        cpf: "234.567.890-00",
        data_nascimento: "1992-07-25"
    },
    {
        nome_completo: "Luiz Fernandes",
        email: "luiz@example.com",
        contato: "(21) 97654-3210",
        cpf: "876.543.210-00",
        data_nascimento: "1988-02-14"
    },
    {
        nome_completo: "Laura Pereira",
        email: "laura@example.com",
        contato: "(31) 98876-5432",
        cpf: "345.678.901-00",
        data_nascimento: "1995-09-03"
    },
    {
        nome_completo: "Rafaela Santos",
        email: "rafaela@example.com",
        contato: "(11) 93456-7890",
        cpf: "543.210.987-00",
        data_nascimento: "1997-11-28"
    },
    {
        nome_completo: "Pedro Almeida",
        email: "pedro@example.com",
        contato: "(21) 96543-2109",
        cpf: "654.321.098-00",
        data_nascimento: "1987-04-10"
    },
    {
        nome_completo: "Fernanda Costa",
        email: "fernanda@example.com",
        contato: "(31) 98876-5432",
        cpf: "789.012.345-00",
        data_nascimento: "1983-08-17"
    },
    {
        nome_completo: "Roberto Oliveira",
        email: "roberto@example.com",
        contato: "(11) 94567-8901",
        cpf: "210.987.654-00",
        data_nascimento: "1994-12-05"
    }
];


module.exports = clientes;

