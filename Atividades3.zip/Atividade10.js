// Atividade10

const ler = require('readline-sync');

let doacoes = [];
let instituicoes = [
    { nome: "Instituição A", endereco: "Rua A, 123", telefone: "(00) 1234-5678" },
    { nome: "Instituição B", endereco: "Rua B, 456", telefone: "(00) 2345-6789" },
    { nome: "Instituição C", endereco: "Rua C, 789", telefone: "(00) 3456-7890" }
];

console.log("Nome:", instituicoes[0].nome);
console.log("Endereço:", instituicoes[0].endereco);
console.log("Telefone:", instituicoes[0].telefone);

console.log("--------------------------");

function informacoes(){
    const nomeDoador = ler.question("Nome do doador: ");
    const valorDoacao = parseFloat(ler.question("Valor da doação: "));
    
    doacoes.push({ nomeDoador, valorDoacao });
    distribuirDoacao(valorDoacao);
};

function distribuirDoacao(valor) {
    const valorPorInstituicao = valor / instituicoes.length;
    
    instituicoes.forEach(instituicao => {
    instituicao.totalDoacoes += valorPorInstituicao;
});
}
function imprimirDoacoes(){
    console.log("Detalhes das distribuições:");
    instituicoes.forEach(instituicao => {
    console.log(`Instituição: ${instituicao.nome} - Total de Doações: R$ ${instituicao.totalDoacoes.toFixed(2)}`);
});
}

informacoes();
informacoes();
informacoes();

imprimirDoacoes();

