// Atividade11

const ler = require('readline-sync');

function createAlphabetMatrix() {
    var alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    var matrix = [];
    var index = 0;

for (var i = 0; i < 5; i++) {
    var row = [];
    for (var j = 0; j < 5; j++) {
        row.push(alphabet[index]);
        index = (index + 1) % alphabet.length;
}
    matrix.push(row);
}
    return matrix;
}

function printMatrix(matrix) {
    for (var i = 0; i < matrix.length; i++) {
    console.log(matrix[i].join(' '));
}
}

function extractHiddenMessage(matrix, rows, columns) {
    console.log("Mensagem oculta:");
    rows.forEach(function(row) {
    var message = "";
    matrix[row - 1].forEach(function(letter, index) {
if (columns.includes(index + 1)) {
    message += letter;
}
});
    console.log(message);
});
}

var alphabetMatrix = createAlphabetMatrix();

console.log("Matriz de letras:");
printMatrix(alphabetMatrix);

var readline = require('readline');
var rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

rl.question("Digite as linhas (números separados por espaço): ", function(rowInput) {
    rl.question("Digite as colunas (números separados por espaço): ", function(columnInput) {
    var rows = rowInput.trim().split(' ').map(Number);
    var columns = columnInput.trim().split(' ').map(Number);

    extractHiddenMessage(alphabetMatrix, rows, columns);

    rl.close();
});
});


