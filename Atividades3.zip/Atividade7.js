// Atividade7

const readline = require('readline');

function criarMatrizAssentos(rows, cols) {
    const assentos = [];
for (let i = 0; i < rows; i++) {
    const fila = [];
    for (let j = 0; j < cols; j++) {
    fila.push('Disponível');
        }
assentos.push(fila);
    }
return assentos;
}

function imprimirAssentos(assentos) {
    console.log("Mapa de Assentos:");
    console.table(assentos);
}

function reservarAssento(assentos, fila, assento) {
if (fila >= 1 && fila <= assentos.length && assento >= 1 && assento <= assentos[0].length) {
    if (assentos[fila - 1][assento - 1] === 'Disponível') {
    assentos[fila - 1][assento - 1] = 'Ocupado';
    console.log(`Assento na fila ${fila}, assento ${assento} reservado com sucesso.`);
} else {
    console.log(`Assento na fila ${fila}, assento ${assento} já está ocupado.`);
}
} else {
    console.log("Assento inválido.");
}
}

const assentos = criarMatrizAssentos(5, 5);

imprimirAssentos(assentos);

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function iniciarReserva() {
    rl.question('Digite o número da fila: ', (filaInput) => {
    const fila = parseInt(filaInput);
    rl.question('Digite o número do assento: ', (assentoInput) => {
    const assento = parseInt(assentoInput);

    reservarAssento(assentos, fila, assento);
    imprimirAssentos(assentos);
    rl.close();
});
});
}

iniciarReserva();








