// Atividade3

const ler = require('readline-sync');

const playlist = [
    {
      titulo: "Bohemian Rhapsody",
      artista: "Queen",
      duracao: "6:07"
    },
    {
      titulo: "Freestyle 3",
      artista: "Ken Carson",
      duracao: "2:22"
    },
    {
      titulo: "Hotel California",
      artista: "Eagles",
      duracao: "6:30"
    },

];

console.log(playlist);

let resposta = ler.question("Você quer adicionar mais uma música na playlist? (sim/não)");

while (resposta === 'sim') {
    const titulo = ler.question("Nome da música: ");
    const artista = ler.question("Artista: ");
    const duracao = ler.question("Duração da música: ");
    playlist.push({titulo, artista, duracao});
    
resposta = ler.question("Você quer adicionar mais uma música na playlist? (sim/não)");
}

console.log(playlist);

let duracaoTotal = 0;

for (let musica of playlist) {
    const duracaoArray = musica.duracao.split(":");
    const minutos = parseInt(duracaoArray[0]);
    const segundos = parseInt(duracaoArray[1]);
    const duracaoSegundos = minutos * + segundos;
    duracaoTotal += duracaoSegundos;
}

const duracaoMinutos = Math.floor(duracaoTotal / 60);
const duracaoSegundosRestantes = duracaoTotal % 60;

console.log(`O tempo total da playlist é ${duracaoMinutos}:${duracaoSegundosRestantes}`);