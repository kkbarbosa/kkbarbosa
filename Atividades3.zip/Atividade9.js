// Atividade9

let jogadores = [];

function adicionarJogador(nome, pontuacao){
    jogadores.push({nome, pontuacao});
}

function classificarJogador(){
    jogadores.sort((a, b) => b.pontuacao - a.pontuacao);
}

function imprimirRanking(){
    console.log("Ranking dos jogadores: ");
    jogadores.forEach((jogador, indice) => {
        console.log(`${indice + 1}: Nome do player: ${jogador.nome} - Pontuação: ${jogador.pontuacao}`);
    });
}

adicionarJogador("Alice", 100);
adicionarJogador("Bob", 80);
adicionarJogador("Carol", 120);
adicionarJogador("David", 90);

classificarJogador();
imprimirRanking();