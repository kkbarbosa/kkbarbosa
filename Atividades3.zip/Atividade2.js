// Atividade2

function frasesAleatórias() {
    const array1 = ["O sol", "A lua", "Uma estrela", "Um rio", "Uma montanha"];
    const array2 = ["brilha", "ilumina", "reflete", "aquece", "encanta"];
    const array3 = ["o mundo", "a terra", "o céu", "a paisagem", "o horizonte"];
    const array4 = ["com amor", "com beleza", "com esperança", "com magia", "com serenidade"];
    const array5 = ["todos os dias", "em todas as estações", "a cada momento", "em toda jornada", "na vida inteira"];

    let frases = [];

    for (let i = 0; i < 5; i++) {
        const palavra1 = array1[Math.floor(Math.random() * array1.length)];
        const palavra2 = array2[Math.floor(Math.random() * array2.length)];
        const palavra3 = array3[Math.floor(Math.random() * array3.length)];
        const palavra4 = array4[Math.floor(Math.random() * array4.length)];
        const palavra5 = array5[Math.floor(Math.random() * array5.length)];

        frases.push(`${palavra1} ${palavra2} ${palavra3} ${palavra4} ${palavra5}`);
    }

    return frases;
}


const históriasAleatórias = frasesAleatórias();

históriasAleatórias.forEach((frase, i) => {
    console.log(`Frase ${i + 1}: ${frase}`);
});
