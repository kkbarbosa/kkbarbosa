// Atividade14

const readline = require('readline-sync');

let filmes = [{
    titulo: "O Poderoso Chefão",
    avaliacoes: [],
},
{
    titulo: "Interestelar",
    avaliacoes: [],
},
{
    titulo: "Cidade de Deus",
    avaliacoes: [],
},
{
    titulo: "Matrix",
    avaliacoes: [],
},
{
    titulo: "Pulp Fiction",
    avaliacoes: [],
}
];

function avaliarFilmes(){
    let titulofilme = readline.question("Digite o titulo do filme: ");
    
    let filme = filmes.find(f => f.titulo === titulofilme);
if (filme) {
    let avaliacao = readline.question("Digite a sua avaliação: ");
switch (avaliacao) {
    case "1-2 Estrelas":
        filme.avaliacoes.push(1);
        break;
    case "3 Estrelas":
        filme.avaliacoes.push(3);
        break;
    case "4-5 Estrelas":
        filme.avaliacoes.push(5);
        break;
    default:
        console.log("Essa avaliação não existe");
        break;
}
    console.log("Avaliação Armazenada com sucesso!");
    
} else {
    console.log("Filme não encontrado");
}
}

avaliarFilmes();
console.log("Avaliações dos filmes: ")
filmes.forEach(filme => {
    console.log(`${filme.titulo}: ${filme.avaliacoes.length > 0 ? filme.avaliacoes.join(', ') : 'Sem avaliações'}`);
});
