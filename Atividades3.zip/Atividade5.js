// Atividade5

const carrinhoDeCompras = {
    "Frutas": [
        { nome: "Maçã", preço: 2.50, quantidade: 3 },
        { nome: "Banana", preço: 1.80, quantidade: 2 },
        { nome: "Laranja", preço: 3.00, quantidade: 1 }
    ],
    "Laticínios": [
        { nome: "Leite", preço: 3.50, quantidade: 1 },
        { nome: "Queijo", preço: 5.20, quantidade: 2 }
    ],
    "Higiene": [
        { nome: "Sabonete", preço: 1.50, quantidade: 3 },
        { nome: "Escova de dentes", preço: 2.00, quantidade: 1 }
    ]
};

function calcularTotal() {
var totalGeral = 0;
for (var categoria in carrinhoDeCompras) {
    var totalPorCategoria = 0;
    var produtos = carrinhoDeCompras[categoria];

console.log("Categoria: " + categoria);

for (var produto of produtos) {
    var precoTotalProduto = produto.preço * produto.quantidade;
    totalPorCategoria += precoTotalProduto;
    totalGeral += precoTotalProduto;
console.log("- " + produto.nome + ": R$ " + precoTotalProduto.toFixed(2));
}
console.log("Total da categoria " + categoria + ": R$ " + totalPorCategoria.toFixed(2) + "\n");
}
console.log("Total geral: R$ " + totalGeral.toFixed(2));
}

calcularTotal();