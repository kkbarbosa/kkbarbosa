// Atividade4

var classificacoes = [
    [8, 5, 9],
    [7, 9, 6],
    [9, 8, 7]
];
var categorias = ["Aventura", "Drama", "Comédia"];

function recomendarFilmes(){
for (var i = 0; i < classificacoes.length; i++) {
    var usuario = "Usuário " + (i + 1);
    var classificacoesUsuario = classificacoes[i];
    var indiceMaximo = classificacoesUsuario.indexOf(Math.max(...classificacoesUsuario)); 
    var categoriaRecomendada = categorias[indiceMaximo]
console.log(usuario + " - Sua categoria preferida é " + categoriaRecomendada + " com uma classificação de " + Math.max(...classificacoesUsuario));

switch (categoriaRecomendada) {
    case "Aventura":
        console.log("Sugestão de filme do genero aventura, filme recomendado: 'Roberto Carlos em Ritmo de Aventura'");
        break;
    case "Drama":
        console.log("Sugestão de filme do genero drma, filme recomendado: 'Central Station'");
    case "Comédia":
        console.log("Sugestão de filme do genero comédia, filme recomendado: 'Zoolander'");
    default:
        console.log("Não a sugestões de filmes");    
    break;
}
console.log("\n");
}
}
recomendarFilmes();