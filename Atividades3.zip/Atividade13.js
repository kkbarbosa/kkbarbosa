// Atividade 13

let matriz = new Array(10).fill(0).map(() => new Array(10).fill(0));

for (let i = 0; i < 10; i++) {
  for (let j = 0; j < 10; j++) {
    if (i === j) {
      matriz[i][j] = 1;
    } else if (i + j === 9) {
      matriz[i][j] = 2;
    } else {
      matriz[i][j] = 0;
    }
  }
}

console.table(matriz);