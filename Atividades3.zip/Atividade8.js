// Atividade8

const readline = require("readline-sync");

let livros = [];

function addLivro() {
   const titulo = readline.question("Digite o titulo do livro: ");
   const categoria = readline.question("Digite a categoria do livro: ");
   livros.push({ titulo, categoria });
   
   const resposta = readline.question("Quer adicionar mais livros? (sim/não)");
   
   if (resposta.toLowerCase() === "sim") {
    addLivro();
   } else {
    mostrarLivros();
   }
}
   
function mostrarLivros() {
   livros.sort((a, b) => a.titulo.localeCompare(b.titulo));
   console.log("livros por ordem alfabética: ");
   for (const livro of livros) {
    console.log(`Titulo: ${livro.titulo} - Categoria: ${livro.categoria}`)
   }
};

addLivro();
