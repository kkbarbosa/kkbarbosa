// Atividade12

let atividades = [{
    'Tomar banho': 0.5,
    'Andar de bicicleta': 0,
    'Usar o carro': 2,
    'Reciclar papel': -1,
    'Usar energia solar': -3
}];

function calcularImpactoTotal(atividades){
var impactoTotal = 0;
for (const atividade in atividades) {
    impactoTotal += atividades[atividade];
}
return impactoTotal;
}

function imprimirSolucoes(){
    console.log("Detalhes das distribuições:");
    instituicoes.forEach(instituicao => {
    console.log(`Instituição: ${instituicao.nome} - Total de Doações: R$ ${instituicao.totalDoacoes.toFixed(2)}`);
});
}

function sugerirMelhorias(impactoTotal) {
if (impactoTotal > 0) {
    console.log("Seu impacto ambiental total é de " + impactoTotal + " unidades de carbono. Você pode considerar reduzir seu impacto ambiental reduzindo ou substituindo atividades que tenham um alto impacto.");
} else if (impactoTotal < 0) {
    console.log("Parabéns! Seu impacto ambiental total é negativo (" + impactoTotal + " unidades de carbono), o que significa que suas atividades têm um impacto positivo no meio ambiente. Continue com as boas práticas!");
} else {
    console.log("Seu impacto ambiental total é neutro. Considere maneiras de reduzir ou compensar seu impacto ambiental.");
}
}

var impactoTotal = calcularImpactoTotal(atividades);

console.log("O impacto ambiental total é de " + impactoTotal + " unidades de carbono.");

sugerirMelhorias(impactoTotal);
