// Atividade3

const ler = require('readline-sync');

function lerArray() {
    const array = [];
    for (let i = 0; i < 10; i++) {
    let elemento;
    do {
        elemento = ler.questionInt(`Digite o elemento ${i + 1}: `);
        if (elemento <= 0) {
        console.log("Por favor, digite um número inteiro e positivo.");
}
} while (elemento <= 0);
    array.push(elemento);
}
    return array;
}

function criarSegundoArray(arrayOriginal) {
const segundoArray = [];
    for (let i = 0; i < arrayOriginal.length; i++) {
    if (i % 2 === 0) { // Elemento de índice par
    segundoArray.push(arrayOriginal[i] / 2);
} else { // Elemento de índice ímpar
    segundoArray.push(arrayOriginal[i] * 3);
}
}
    return segundoArray;
}

console.log("Digite os elementos do array original:");
const arrayOriginal = lerArray();

const segundoArray = criarSegundoArray(arrayOriginal);

console.log("Array Original:", arrayOriginal);
console.log("Segundo Array:", segundoArray);