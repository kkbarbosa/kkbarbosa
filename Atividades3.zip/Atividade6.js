// Atividade6

const votosDosEleitores = {
    "Candidato A": [
        { nome: "João", idade: 35, votos: 1234 },
        { nome: "Maria", idade: 28, votos: 5678 },
        { nome: "Pedro", idade: 45, votos: 1234 }
    ],
    "Candidato B": [
        { nome: "Ana", idade: 40, votos: 5678 },
        { nome: "Carlos", idade: 55, votos: 1234 }
    ],
    "Candidato C": [
        { nome: "Fernanda", idade: 30, votos: 5678 },
        { nome: "Rafael", idade: 50, votos: 1234 },
        { nome: "Mariana", idade: 38, votos: 9012 }
    ]
};

console.log(votosDosEleitores);
let totaldeVotosporCandidatos = {};

for (let candidato in votosDosEleitores) {
    let votos = votosDosEleitores[candidato];
    let totalVotos = 0;
    votos.forEach(eleitor => {
    totalVotos++;  
});
totaldeVotosporCandidatos[candidato] = totalVotos;
}

let vencedor = "";
let maiorNumerodeVotos = 0;

for (let candidato in totaldeVotosporCandidatos) {
if (totaldeVotosporCandidatos[candidato] > maiorNumerodeVotos) {
vencedor = candidato;
maiorNumerodeVotos = totaldeVotosporCandidatos[candidato];
} else if (totaldeVotosporCandidatos[candidato] === maiorNumerodeVotos) {
vencedor = "Empate";
    }
}

console.log("Total de votos por candidato:", totaldeVotosporCandidatos);
console.log("Vencedor:", vencedor);