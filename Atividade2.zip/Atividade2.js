// Atividade2

const ler = require("readline-sync");


let chamadas = [];
let chamadasPrioridade = [];    


function priorizarChamadas() {
    chamadasPrioridade = chamadas.filter((chamadas) => chamadas.tipo.toLowerCase() === "incendio");
    chamadas = chamadas.filter((chamadas) => chamadas.tipo.toLowerCase() !== "incendio");
}

function exibirchamadas(){
    console.log("Chamadas de Alta Prioridade: ");
    chamadasPrioridade.forEach((chamada, i) => {
    console.log(`${i + 1} ${chamada.tipo} - ${chamada.mensagem}`);
    });
} 
    console.log("Chamadas Regulares: ");
    chamadas.forEach((chamada, i) => {
    console.log(`${i + 1} ${chamada.tipo} - ${chamada.mensagem}`);
});

function capturarChamadas(){
    while (true) {
        const tipo = ler.question("Digite o tipo de chamada ou digite 'sair' para finalizar: ");
        if (tipo.toLowerCase() === "sair"){
            priorizarChamadas();
            exibirchamadas();
            break;
    } else {
        const mensagem = ler.question(`Digite a mensagem para ${tipo}: `);
        chamadas.push({ tipo, mensagem });
    }
}
}
console.log("Capturando chamadas");
capturarChamadas();
