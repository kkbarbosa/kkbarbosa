// Atividade4

const readline = require("readline-sync");

const nomes = ["Lucas", "Maria", "José", "Ana", "João"];

console.log("Lista inicial de nomes: " + nomes);
let resposta = readline.question("Você quer adicionar mais um nome na lista? (sim/não)");

while (resposta.toLowerCase() === "sim") {
    const novoNome = readline.question("Digite um nome para ser adicionado: ");

    if (nomes.indexOf(novoNome) === -1 )  {
        nomes.push(novoNome);
        console.log(`${novoNome} foi adicionado`);
    } else {
        console.log(`${novoNome} já esta na lista`);
    }
    resposta = readline.question("Você quer adicionar mais um nome na lista? (sim/não)");
}

console.log("Lista final de nomes:", nomes);
