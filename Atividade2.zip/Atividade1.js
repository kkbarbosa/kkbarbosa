// Atividade 1

let produtos = [
    { nome: "Smartphone X", quantidade: 3 },
    { nome: "Fone de Ouvido Wireless", quantidade: 0 },
    { nome: "Notebook Ultra", quantidade: 7 },
    { nome: "Máquina de Café Expresso", quantidade: 10 },
    { nome: "Câmera DSLR Profissional", quantidade: 34 }
  ];

console.log(produtos);

produtos.sort();
console.log("Produtos em ordem alfabetica: ")
console.log(produtos);

let remover_produto = produtos.findIndex(p => p.nome === "Fone de Ouvido Wireless");
if (remover_produto !== -1) {
    produtos.splice(remover_produto, 1);
}

console.log("Prduotos após remoção: ")
console.log(produtos);

