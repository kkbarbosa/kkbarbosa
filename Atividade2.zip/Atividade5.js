// Atividade5

const readline = require("readline-sync");

let funcionarios = [
    {Nome: "Ana",
    Departamento: "RH",
    Cargo: "Gerente de Recursos Humanos",
    Anos_serviço: 5},
    {Nome: "João",
    Departamento: "Vendas",
    Cargo: "Representante de Vendas",
    Anos_serviço: 3},
    {Nome: "Maria",
    Departamento: "TI",
    Cargo: "Desenvolvedora de Software",
    Anos_serviço: 8}
];

function listarFunconarios(){
    console.log("Lista de funcionarios");
    funcionarios.forEach(funcionarios => {
        console.log(`${funcionarios.Nome} - ${funcionarios.Departamento} - ${funcionarios.Cargo} - ${funcionarios.Anos_serviço} anos de serviço`);
    });
}

function buscarFuncionario(nome){
    const funcionarioEncontrado = funcionarios.find(funcionario => funcionario.Nome.toLowerCase() === nome.toLowerCase());
        if (funcionarioEncontrado){
            console.log("Detalhes do funcionário encontrado:");
            console.log(`Nome: ${funcionarioEncontrado.Nome}`);
            console.log(`Departamento: ${funcionarioEncontrado.Departamento}`);
            console.log(`Cargo: ${funcionarioEncontrado.Cargo}`);
            console.log(`Anos de serviço: ${funcionarioEncontrado.Anos_serviço}`);
        } else {
            console.log("Funcionário não encontrado");
        }
    }

console.log("Lista inicial de funcionários: ");
listarFunconarios();

let resposta = readline.question("Você quer adicionar mais um funcionário na lista? (sim/não)");

while (resposta.toLowerCase() === "sim") {
    const novoFuncionario = {};

    novoFuncionario.Nome = readline.question("Digite o nome desse funcionário: ");
    novoFuncionario.Departamento = readline.question("Digite o departamento desse funcionário: ");
    novoFuncionario.Cargo = readline.question("Digite o cargo desse funcionário: ");
    novoFuncionario.Anos_serviço = readline.question("Digite os anos de serviço desse funcionário: ");

    funcionarios.push(novoFuncionario);
    console.log(`${novoFuncionario.Nome} foi adicionado`);

    resposta = readline.question("Você quer adicionar mais um fincionário?");
}

console.log("Lista final de nomes:");
listarFunconarios();

const nomeBusca = readline.question("Buscar funcionário por nome (digite sair para sair):");
if (nomeBusca.toLowerCase() !== "sair"){
    buscarFuncionario(nomeBusca);
}
