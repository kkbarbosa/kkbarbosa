// Atividade6

const itens = [ "Tomates", "Queijo", "Pão", "Cebolas", "Maçãs"];

itens.sort();
console.log("Itens em ordem alfabetica:");
console.log(itens);