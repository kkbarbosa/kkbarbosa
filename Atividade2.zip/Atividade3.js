// Atividade3

const readline = require("readline-sync");

let livro = [];

function addLivro() {
   const titulo = readline.question("Digite o titulo do livro: ");
   const categoria = readline.question("Digite a categoria do livro: ");
   const livros = livro.push({categoria, titulo});

   const resposta = readline.question("Quer adicionar mais livros? (sim/não)");
   if (resposta.toLowerCase() === "sim") {
    addLivro();
   } else {
    mostrarLivros();
   }
}

function mostrarLivros() {
    const analisarLivros = livro.slice(0, 10);
    const contarCategoria = {};
    
    analisarLivros.forEach(livro => {
    const categoria = livro.categoria;
    if (contarCategoria[categoria]) {
        contarCategoria[categoria] += 1;
    } else {
        contarCategoria[categoria] = 1;
    }
    });

    console.log("Contagem de livros por categoria: ");
    Object.entries(contarCategoria).forEach(([categoria, contagem]) => {
        console.log(`${categoria} ${contagem}`);
    });
}
addLivro();

