// atividade6
const readline = require("readline-sync");

const num = parseInt(readline.question("Digite um número para gerar a tabela de multiplicação: "));

for (let i = 1; i < 10; i++) {
    const result = num * i;
    console.log(`${num} x ${i} = ${result}`)
}