// atividade8

const readline = require('readline-sync');

var num = parseInt(readline.question("Digite valores: "));
var soma = 0;
var contador = 0;

do{
    num = parseInt(readline.question("Digite 0 para sair: "))
    if (num !== 0){
        soma += num;
        contador++;
    }
} while (num !== 0) {
    if (contador === 0) {
        console.log("Nenhum número inserido, imposivel calcular a média!")
    } else {
        const media = soma / contador;
        console.log("A média dos números inseridos são: " + media)
    }
}