// atividade4

const readline = require('readline-sync');
const velocidadeCarro = parseFloat(readline.question("Qual é a velocidade do carro: "));

var velocidadePermitida = 50;
function verificarMulta(velocidadeCarro, velocidadePermitida){
const percentualExcesso = ((velocidadeCarro - velocidadePermitida) / velocidadePermitida * 100);

    if (percentualExcesso <=10){
        return "multa leve";
} else if (percentualExcesso > 10 && percentualExcesso <=20) {
        return "multa grave";
} else if (percentualExcesso > 20){
        return "licença suspensa";
} else {
    return "dentro do limite permitido";
}
}
const result = verificarMulta(velocidadeCarro, velocidadePermitida);
console.log("Resultado: " + result);
