// atividade5
const readline = require('readline-sync');

const numeroAlvo = Math.floor(Math.random() * 10 ) + 1;

let palpite = null;

while (palpite !== numeroAlvo) {
    palpite = parseInt(readline.question("Adivinhe um número entre 1 e 10:"), 10);

}

if (palpite < numeroAlvo) {
    console.log("Seu palpite é menor que o número alvo");
} else if (palpite > numeroAlvo){
    console.log("Seu palpite é maior que o número alvo");
} else { 
    console.log("Parabens você acertou o número!!");
}