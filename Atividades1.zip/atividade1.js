// atividade 1
const readline = require('readline-sync');

const salarioAnual = parseFloat(readline.question("Digite o seru salário anual: "))   
const imposto = calcularImposto(salarioAnual);

function calcularImposto(salarioAnual){
    if (salarioAnual <= 22847.76){
        return 0;
    } else if (salarioAnual <= 33919.80){
        return (salarioAnual - 22847.76) * 0,75;
    } else if (salarioAnual <= 45012.60) {
        return (salarioAnual - 33919.80) * 0.15 + 1100.71;
    } else {
        return (salarioAnual - 45012.60) * 0,25 + 2966.15;
}

}
console.log("Imposto a ser pago: R$ " + imposto.toFixed(2));