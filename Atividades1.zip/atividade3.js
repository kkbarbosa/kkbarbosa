// atividade3

const readline = require('readline-sync');

function celsiusParaFahrenheit(celsius) {
    return (celsius * 9 / 5) + 32;
}

function fahrenheitParaCelsius(fahrenheit) {
    return (fahrenheit - 32) * 5 / 9;
}

const escolha = readline.question("Escolha a conversão desejada:\n1. Celsius para Fahrenheit\n2. Fahrenheit para Celsius");

if (escolha === '1') {
    const celsius = parseFloat(readline.question("Digite a temperatura em Celsius: "));
    const fahrenheit = celsiusParaFahrenheit(celsius);
    console.log(`${celsius} graus Celsius equivalem a ${fahrenheit.toFixed(2)} graus Fahrenheit.`);
} else if (escolha === '2') {
    const fahrenheit = parseFloat(readline.question("Digite a temperatura em Fahrenheit: "));
    const celsius = fahrenheitParaCelsius(fahrenheit);
    console.log(`${fahrenheit} graus Fahrenheit equivalem a ${celsius.toFixed(2)} graus Celsius.`);
} else {
    console.log("Escolha inválida. Por favor, escolha 1 ou 2.");
}