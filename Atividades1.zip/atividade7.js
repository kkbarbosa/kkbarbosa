// atividade7

const readline = require("readline-sync");

var num = parseInt(readline.question("Digite um número: "));

if (num < 0) {
   console.log("Não é possivel calcular fatoria desse número!!")
} else 
    var fatores = 1;
for (var i = 1; i <= num; i++) {
    fatores *= i;
}

console.log("Os fatores de " + num + " são: " + fatores);
