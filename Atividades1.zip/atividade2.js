// atividade2
const readline = require('readline-sync');

var num1;

num1 = readline.question("Digite um numero: ");

function isPrimo(num1){
    if (num1 <= 1) {
        return false;
    } 
    for (let i = 2; i <= Math.sqrt(num1); i++) {
        if (num1 % i === 0) {
            return false;
    }
}        
    return true;
}

if (isPrimo(num1)){
    console.log(num1 + " é um numero primo");
} else {
    console.log(num1 + " não é um numero primo");
}