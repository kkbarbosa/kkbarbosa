// Capturando e exibindo valores de um array com whie

const ler = require("readline-sync");

let doces = [];
let check = false;

while (!check) {
  let doce = ler.question("Informe um nome de um doce ou digite 'sair' para sair: ").toLowerCase();  
   if (doce === 'sair') {
    check = true;
   } else {
    doces.push(doce);
  }
}

for (let i = 0; i < doces.length; i++) {
  console.log(`=> ${doces[i]}`);
}