//Inicializando variáveis 

let num1 = 100;
let outro_num1 = num1;
let num2;
console.log(num1);
console.log(outro_num1);
num2 = 70;
console.log(num2);