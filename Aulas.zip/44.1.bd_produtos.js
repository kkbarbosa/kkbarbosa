let produtos = [
    { id: 1, nome: "Camiseta", quantidade: 20, preco: 98.60 },
    { id: 2, nome: "Calça", quantidade: 15, preco: 129.90 },
    { id: 3, nome: "Tênis", quantidade: 30, preco: 199.99 },
    { id: 4, nome: "Jaqueta", quantidade: 10, preco: 249.50 },
    { id: 5, nome: "Bermuda", quantidade: 25, preco: 79.99 },
    { id: 6, nome: "Meia", quantidade: 50, preco: 9.99 },
    { id: 7, nome: "Boné", quantidade: 5, preco: 49.90 },
    { id: 8, nome: "Vestido", quantidade: 12, preco: 149.75 },
    { id: 9, nome: "Sapato", quantidade: 18, preco: 179.00 },
    { id: 10, nome: "Blusa", quantidade: 22, preco: 69.95 }
];

module.exports = produtos;
