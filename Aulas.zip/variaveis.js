//Variáveis

var num1;
var num1;
console.log(num1);

let num2;
//let num2; /* não é aceito declarar a mesma variável mais de uma vez */
console.log(num2);