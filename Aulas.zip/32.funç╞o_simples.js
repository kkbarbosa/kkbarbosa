// Função Simples

function exibirData(){
    console.log(`Hoje é ${new Date().toString()}`)
}

function despedida(){
    console.log("Até mais");
}

exibirData();
despedida();