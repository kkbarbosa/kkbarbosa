// Exibindo informações de um objeto {} forEach/of/in

let produtos = [
    {nome: "Teclado USB", preco: 180.90, quantidade: 3},
    {nome: "Mouse sem Fio", preco: 79.99, quantidade: 5},
    {nome: "Monitor LED 24'", preco: 899.00, quantidade: 2},
    {nome: "Headset Gamer", preco: 250.50, quantidade: 4},
    {nome: "Webcam HD", preco: 120.00, quantidade: 6},
    {nome: "Pen Drive 32GB", preco: 29.90, quantidade: 10},
    {nome: "Cadeira Gamer", preco: 699.99, quantidade: 3},
    {nome: "Smartphone Android", preco: 899.00, quantidade: 8},
    {nome: "Impressora Multifuncional", preco: 299.99, quantidade: 5},
    {nome: "Roteador Wi-Fi", preco: 69.90, quantidade: 7},
    {nome: "Caixa de Som Bluetooth", preco: 149.90, quantidade: 4}
];

for (let produto of produtos) {
    if (produto.preco > 150) {
        console.log(`Nome: ${produto.nome}`);
    }
}

console.log("--------------------------------")
//nomes dos produtos com valor menor que 100 e a soma total de cada um e ovalor geral
let soma, result = 0;
for (let produto in produtos) {
    if(produtos[produto].preco < 100){
    
    soma = produtos[produto].preco * produtos[produto].quantidade;
    result += soma;
    console.log(`Nome: ${produtos[produto].nome} - Total: ${soma}`);

    }
}
console.log(`Total geral: ${result.toFixed(2)}`);

console.log("--------------------------------")
//nome dos produtos com as quantidades maiores que 5
produtos.forEach(produto => {
    if (produto.quantidade > 5) {
        console.log(`Nome: ${produto.nome} - Valor: ${produto.preco}`);
    }
});

