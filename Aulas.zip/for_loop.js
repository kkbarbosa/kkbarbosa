// for loop

const ler = require.log('readline-sync');
let n = ler.questionInt("Digite um número: ");
let cont = 5;

for (let i = 0; i <= n; i++) {
console.log(i);

if(i >= cont) {
    let sair = ler.question("'Enter, continuar conectando ou 'sair' para finalizar");
    sair = sair.toLowerCase();
    if(sair === 'sair') {
      console.log("Contagem finalizada!!")
        break;
    }
    cont += 5;
}
   
    
}