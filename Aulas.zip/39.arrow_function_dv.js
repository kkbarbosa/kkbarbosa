// Arro funtion aplicando descontos em valores

const ler = require('readline-sync');

let result = (valor, desconto) => (valor + (valor * desconto))  / 100;

let v1 = ler.questionFloat("Digite o valor: ");
let desc = ler.questionFloat("Digite desconto: ");

let re = result(v1, desc).toFixed(2);

console.log(`O valor de ${v1} com disconto de ${desc}% será de R$ ${re}.`);
