// Salvar dados em um arquivo JSON

const fs = require('fs');

let usuarios = [
    {nome: "Marta Silva", idade: 23, email: "martasilva@gmail.com"},
    {nome: "Danyel Sena com Y", idade: 18, email: "danyelcomy@hotmail.com"}, 
    {nome: "Danilo Silva", idade: 25, email: "danielreidelas@gmail.com"},
    {nome: "Marta Silva", idade: 16, email: "martasilva@hotmail.com"},
    {nome: "Silvana Dias", idade: 16, email: "silvana@gmail.com"},
    {nome: "Ana Caroline", idade: 20, email: "aninha@outlook.com"},
];

usuarios.push({nome: "Fulana", idade: 25, email: "fulano@gmail.com"});

const dadosJSON = JSON.stringify(usuarios, null, 2);

fs.writeFile('45.1.usuarios.json', dadosJSON, 'utf-8', (erro) => {
    if (erro){
        console.log("Erro ao gravar dados no JSON", erro)
    } else {
        console.log("Dados salvos com sucesso em 45.1.usuarios.JSON")
    }
});

const exibirDados = fs.readFileSync('45.1.usuarios.JSON', 'utf-8');
let users = JSON.parse(exibirDados);
console.log(users);