// constantes

const num1 = 100;
const palavra = "Hello";
palavra = "Hello";

console.log(num1);
console.log(palavra);