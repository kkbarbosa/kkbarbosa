// Arrow function com if else

const ler = require('readline-sync');

let verificavalor = (idade, tipo, valorIngresso) => {
    if (idade >= 18 && tipo === 'normal') {
        return valorIngresso - (valorIngresso * 0.25);
    } else if (idade >= 18 && tipo === 'estudante') {
        return valorIngresso - (valorIngresso * 0.50);
    } else if (idade >= 18 && tipo === 'VIP'){
        return valorIngresso - (valorIngresso * 0.75);
    } else {
        return "Entrada não permitida!";
    }
}

let idade = ler.questionInt("Qual a sua idade?: ");
let tipo = ler.question("Qual o tipo de Ingresso?:").toLowerCase();
let valorIngresso = ler.questionFloat("Qual o valor do ingresso?: ");

console.log(verificavalor(idade, tipo, valorIngresso));

