// Cadastro simples usando JSON

const fs = require('fs');
const ler = require('readline-sync');

fs.access('46.1.users.json', fs.constants.F_OK, (erro) => {
    if (erro) {
        users = [];
        fs.writeFileSync('46.1.users.json', JSON.stringify(users , null, 2), 'utf-8');
    } else {
        let usersJson = fs.readFileSync('46.1.users.json', 'utf-8');
        users = JSON.parse(usersJson);
    }
})

const cadastrar = () => {
    let nome = ler.question("Digite seu nome: ");
    let email = ler.question("Digite seu email:");

    const users_existe = users.nome(usuario => usuario.nome === nome);
    if (users_existe) {
        console.log("Usuario já cadastrado");
    } else {
        users.push({nome: nome, email: email});
        fs.writeFile('46.1.users.json', JSON.stringify(users , null, 2), 'utf-8');
        console.log("Usuario cadastrado com sucesso!")
    }
}

let opt = ler.questionInt("1. Cadastrar ou 2. Visualizar: ");

switch (opt) {
    case 1:
        cadastrar();
        break;
    case 2:
        exibir();
        break;
    default:
        console.log("Opção invalida!")
        break;
}