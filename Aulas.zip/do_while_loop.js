//Do while loop

const ler = require("readline-sync");
let soma = 0, num = 0;

do {
    
    let num = ler.questionInt("Informe um número ou -1 para sair");
    soma += num;

} while (num > 0);

console.log("A soma total dos números digitados é: ", soma);