// array - Matriz 2D

let numeros = [
    [12, 9, 10, 16],
    [17, 7, 6, 11],
    [21, 11, 8, 10],
    [25, 4, 3, 22],
]
console.log(typeof numeros[2][2]);

numeros[3][2] = 34; // trocar o numero 3 por 34
numeros[1][3] = "";

console.log(numeros);