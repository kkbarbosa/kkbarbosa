const ler = require('readline-sync');
let produtos = require('./44.1.bd_produtos')
const { cadProduto, listarProdutos, atualizarProduto, listarProdutoPorId, excluirProduto } = require("./44.2_functions.js");

console.log(produtos)

let check = true;
while (check) {
console.log("-------- Sistema de Gerenciamento de Estoque --------");
console.log("--- Escolha as Opções Abaixo. -----------------------");
console.log("1 - Adicionar Produto. ------------------------------");
console.log("2 - Atualizar Produtos. -----------------------------");
console.log("3 - Listar Produtos. --------------------------------");
console.log("4 - Listar Produto po ID. ---------------------------");
console.log("5 - Excluir Produto por ID. -------------------------");
console.log("6 - Sair. -------------------------------------------");
console.log("-----------------------------------------------------");
let opt = ler.questionInt("=> ");

switch (opt) {
    case 1:
        cadProduto();
        break;
    case 2:
        atualizarProduto();
        break;
    case 3:
        listarProdutos();
        break;
    case 4:
        console.clear();
        listarProdutoPorId();
        break;
    case 5:
        console.clear();
        excluirProduto();;
    case 6:
        console.clear();    
        check = false;
        break;
    default:
        console.clear();
        console.log("Opção Inválida!");
        break;
}  
}

console.log("Sistema finalizado!");
