// Funçoes com 2 oi mais parametros

const ler = require("readline-sync");

function criarEvento(nome , local, data, hora, participantes, custoPorPart) {
    let custototal = calculoCustoTotal(participantes, custoPorPart);
    return{
        Nome: nome,
        Local: local,
        Data: data,
        Hora: hora,
        Participantes: participantes,
        'Custo por Part': custoPorPart,
        'Custo total': custototal
    };

}
function calculoCustoTotal(part, custoPrp) {
let result = part * custoPrp
    return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
    }).format(result);
}



function exibirEvento(evento) {
    console.log("------------------DETALHES DO EVENTO---------------------");
    for (const [chave, valor] of Object.entries(evento)) {
        console.log(`${chave.toUpperCase()} : ${valor}`);
    }
    console.log("---------------------------------------------------------");
}

let EventoTI = criarEvento("Nerd de TI", "Nova Lima", "19-07-2024", "16:30", 50, 120);
exibirEvento(EventoTI);

let no = ler.question("Informe o nome do evento: ");
let lo = ler.question("Informe o local do evento: ");
let dat = ler.question("Informe a data do evento: ");
let ho = ler.question("Informe a hora do evento: ");
let pa = ler.question("Informe o número de participantes: ");
let cPrP = ler.question("Informe o valor do ingresso: ");

let EVT = criarEvento(no, lo, dat, ho, pa, cPrP);
console.clear();
exibirEvento(EVT);
