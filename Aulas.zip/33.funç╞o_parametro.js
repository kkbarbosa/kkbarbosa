// Funções com paramétros

const ler = require("readline-sync");

const DOlAR = 5.16, LIBRA = 6.46, IENE = 0.033, EURO = 5.55;

function formatarReal(real){
    return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
    }).format(real);
}


function convertDolar(valor){
    let resuslt = valor * DOlAR;
    function formatarDolar(result) {new Intl.NumberFormat('en-US', {
    style: 'currency', currency: 'USD'}).format(result);
}    
    console.log("O valor convertido para dolar é: " + resuslt);
}

function convertEuro(valor){
    let resuslt = valor / EURO;
    return new Intl.NumberFormat('de-DE', {
    style: 'currency', currency: 'EUR'}).format(resuslt);
}

function convertLibra(valor){
    return new Intl.NumberFormat('en-GB', {
        style: 'currency', currency: 'GBP'}).format(valor / LIBRA);
};

let valor = function convertIene(valor) {
    return new Intl.NumberFormat('ja-JP', {
        style: 'currency', currency: 'JPY'}).format(valor / IENE);
};

let real = ler.questionFloat("Informe o valor em Reais: ");
let opt = ler.questionInt("Para qual moeda você deseja converter? \n1. Dólar - 2. Euro  - 3. Libra - 4. Iene: ");

switch (opt) {
    case 1:
        convertDolar(real);
        break;
    case 2:
        console.log(`O valor ${formatarReal(real)} convertido para Euro é : ${convertEuro(real)}`);
        break;
    case 3:
        console.log(`O valor ${formatarReal(real)} convertido para Libra é : ${convertLibra(real)}`);
        break;
    case 4:
        console.log(`O valor ${formatarReal(real)} convertido para Iene é : ${valor(real)}`);
        break;  
    default:
        console.log("Essa opção não existe");
        break;
}