// Buscando nomes utilizando função com callback

const ler = require('readline-sync');

let nomes = ["Maria", "João", "Ana", "Pedro", "Danyel Sena com Y", "Carlos", "Luísa", "Rafael", "Juliana", "Paulo"];
 
function busarNome(nome, callback) {
    if (nomes.indexOf(nome) !== -1) {
        callback(null, true);
    } else {
        callback(null, false);        
    }
}

let busca = ler.question("Digite o nome que deseja buscar: ");

let result = function(erro, encontrado) {
    if (erro) {
        console.log("Erro ao buscar o nome!");
    } else {
        if (encontrado) {
            console.log(`O nome ${nomes[nomes.indexOf(busca)]} existe no array nomes!`);
        } else {
            console.log(`O nome ${busca} não existe no array nomes!`);
        }
    }
};

busarNome(busca, result);


