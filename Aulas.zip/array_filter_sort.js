// Ordernar Array em um objeto [{}] ordem alfabética

let usuarios = [
    {nome: "Marta Silva", idade: 23, email: "martasilva@gmail.com"},
    {nome: "Danyel Sena com Y", idade: 18, email: "danyelcomy@hotmail.com"}, 
    {nome: "Danilo Silva", idade: 25, email: "danielreidelas@gmail.com"},
    {nome: "Marta Silva", idade: 16, email: "martasilva@hotmail.com"},
    {nome: "Silvana Dias", idade: 16, email: "silvana@gmail.com"},
    {nome: "Ana Caroline", idade: 20, email: "aninha@outlook.com"},
];

let ordem_alfa = usuarios.sort((x, y) => x.nome.localeCompare(y.nome));
console.log(ordem_alfa);

// Ordenando nomes pela ordem crescente e decrescente

let idade_cresc = usuarios.sort((x, y) => x.idade - y.idade);
console.log(idade_cresc);

let idade_desc = usuarios.sort((x, y) => y.idade - x.idade);
console.log(idade_desc);