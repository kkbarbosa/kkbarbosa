// Arrow function utilizado com loops

let animais = ["Gato", "Cachorro", "Girafa", "Leão", "Tigre", "Avestruz"];

//animais = animais.sort((a, b) => a.localeCompare(a));
animais = animais.sort();
animais.forEach(animais => console.log(`=> ${animais}`));

let numeros = [3, 5, 7, 2, 8, 1];
//numeros.reverse();
numeros.sort();
numeros.forEach(numeros => console.log(`=> ${numeros}`));