// Filtrar elementos Arryas

let nomes = ["Marta", "Jonas", "Claudio", "José", "Geralda", "Maria"];

let numeros = [12, 7, 8, 18, 22, 45, 67];

let usuarios = [
    {nome: "Marta Silva", idade: 23, email: "martasilva@gmail.com"},
    {nome: "Danyel Sena com Y", idade: 18, email: "danyelcomy@gmail.com"}, 
    {nome: "Danilo Silva", idade: 25, email: "martasilva@gmail.com"},
    {nome: "Marta Silva", idade: 16, email: "martasilva@gmail.com"},
];

let ordem_alfa = usuarios.sort((x, y) => x.nome.localeCompare(y.nome));
console.log(ordem_alfa);

let filtrar_nome = nomes.filter(nome => nome.toLowerCase().includes("d"));
let letra = "D"
console.log(filtrar_nome);

let filtrar_nums = numeros.filter(numero => numero < 19);
console.log(filtrar_nums);

let filtrar_menor = usuarios.filter(usuarios => usuarios < 25);
console.log(filtrar_menor);