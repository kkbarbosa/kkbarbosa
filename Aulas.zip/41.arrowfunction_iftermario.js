//Arrow function com operadoor If termário

let result = preco => preco >= 100 ? "Caro" : "Barato";

console.log(result(176.90)); //Caro