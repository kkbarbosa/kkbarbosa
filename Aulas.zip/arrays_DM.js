// Arrays Manipulação de Dados

let nomes = ["Marta", "Jonas", "Claudio", "José", "Geralda", "Maria"];

// adicionar um valor no final da lista

nomes.push("Danyel Sena com Y");
console.log(nomes);
// Ecluir o ultimo valor da lista
nome = nomes.shift();
console.log(nome);
console.log(nomes);
// O pop exclui o ultimo e o shift o primeiro

// Inverter os valores da lista
nomes.reverse(nomes);
console.log(nomes);

//Ordem alfabetica dos valores
nomes.sort();
console.log(nomes);

// Excuir personalizado
let n1 = nomes.slice(1);
console.log(n1);

let n2 = nomes.slice(1,3);
console.log(n2);

let n3 = nomes.slice(-1);
