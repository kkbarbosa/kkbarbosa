var nome = prompt("Digite seu nome: ");
var num1 = prompt("Digite um número: ");
var num2 = prompt("Digite outro número: ");

soma= Number(num1) + Number(num2);

alert("Prezado(a), o resultado da soma é " + soma);
