// Conversão da Variaveis

let num1 = 10;
let num2 = 13;

//Let soma = parseInt(num1) + parseInt(num2);
let soma = Number(num1) + Number(num2);

//String();
//Boolean();

console.log(soma);