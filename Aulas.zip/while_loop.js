// While Loop

const ler = require("readline-sync");

let num = ler.question("Informe um número: ");

while (num > 0) {
    console.log(num);
    num--;
}