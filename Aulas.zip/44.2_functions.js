const ler = require('readline-sync');                          
const produtos = require('./44.1.bd_produtos');              
                                                             
const cadProduto = () => {
    let x = produtos.length;
    let id = x + 1;                                                                            
    let nome = ler.question('Digite o nome do produto: ');
    let quantidade = ler.questionInt('Digite a quantidade do produto: ');
    let preco = ler.questionFloat('Digite o preço do produto: ');
    adicionarProduto(id , nome, quantidade, preco);
}

const adicionarProduto = (id, nome, quantidade, preco) => {                                                 
    produtos.push({id, nome, quantidade, preco});
    console.log("Produto cadastrado com sucesso!");
    ler.question("....");
    console.log("Presione Enter para voltar ao menu.");
    console.clear();
}                                     
const listarProdutoPorId = () => {
    check = true;
    while (check) {
        let id = ler.questionInt("Digite o ID do produto: ");
        let produto = produtos.find(prod => prod.id === id);
        if (produto) {
            console.log(
            `ID: ${produto.id} -----------------------------
            Nome: ${produto.nome} 
            Quantidade: ${produto.quantidade}
            Preço: ${produto.preco}
            ------------------------------------------------
            `);
        let opt = ler.questionInt("Deseja buscar outro produto? (1.Sim/2.Não)");
        if (opt === 1) {
            console.clear();             
        } else {
            check = false;
            console.clear();
        } 
    } else {
        console.clear();
        setTimeout(() => { console.log("Produto não encontrado!!"); }, 3000);
        }
    }
} 

const atualizarProduto = () => {
    check = true;
    while (check) {
        let id = ler.questionInt("Digite o ID do produto que deseja atualizar: ");
        let produto = produtos.find(prod => prod.id === id);
        if (produto) {
        console.log(
            `ID: ${produto.id} -----------------------------
            Nome: ${produto.nome} 
            Quantidade: ${produto.quantidade}
            Preço: ${produto.preco}
            ------------------------------------------------
            `);
        let opt = ler.questionInt("Deseja alterar esse produto? (1.Sim/2.Não)");
        if (opt === 1) {
            console.clear();
            attProduto(id);
            check = false;
        } else {
            console.clear();
    }   
        } else {
            console.clear();
            setTimeout(() => { console.log("Produto não encontrado!!"); }, 3000); 
        }
    }
}



const attProduto = (id) => {
    let produto = produtos.find(prod => prod.id === id);
    let nomeAtt = ler.question(`Informe o novo nome do produto [${produto.nome}]: `);
    let quantidadeAtt = ler.questionInt(`Informe a nova quantidade do produto [${produto.quantidade}]: `);
    let precoAtt = ler.questionFloat(`Informe o novo preço do produto [${produto.preco}]: `);
    produto.nome = nomeAtt;
    produto.quantidade = quantidadeAtt;
    produto.preco = precoAtt;
    console.log("Produto alterado com sucsso!!");
    console.log("...");
    ler.question("Pressione Enter para voltar ao menu.");
    console.clear();
};

const listarProdutos = () => {
    console.log("-------- Produtos Cadastrados --------");
    produtos.forEach((produto => console.log(
        `ID: ${produto.id} -----------------------------
        Nome: ${produto.nome} 
        Quantidade: ${produto.quantidade} --------------
        Preço: ${produto.preco}`)));
    console.log('-------------------------------------');
    ler.question("....");
    console.log("Presione Enter para voltar ao menu.");
}

const excluirProduto = () => {
    check = true;
    while (check) {
        let id = ler.questionInt("Digite o ID do produto: ");
        let produto = produtos.find(prod => prod.id === id);
        let id_ex = produtos.findIndex(p => p.id === id);
        if (produto) {
            console.log(
            `ID: ${produto.id} -----------------------------
            Nome: ${produto.nome} 
            Quantidade: ${produto.quantidade}
            Preço: ${produto.preco}
            ------------------------------------------------
            `);
        let opt = ler.questionInt("Tem certeza que deseja excluir o produto? (1.Sim/2.Não)");
        if (opt === 1) {
            produtos.splice(id_ex, 1);
            console.log(".....");
            console.log("Produto excluido com sucesso!!");
            console.log(".....");
            ler.question("Presione Enter para voltar ao menu.");
            check = false;
        } else {
            check = false;
            console.clear();
        } 
    } else {
        console.clear();
        setTimeout(() => { console.log("Produto não encontrado!!"); }, 3000);
        }
    }
}

module.exports = { cadProduto, listarProdutos, atualizarProduto, listarProdutoPorId, excluirProduto };

// (0_O)
//  /|\
//  / \

//let nome = ler.question('Digite o novo nome do produto: ');
//let quantidade = ler.questionInt('Digite a nova quantidade do produto: ');
//let preco = ler.questionFloat('Digite o novo preço do produto: ');
//check = true;
//while (check) {
//    let id = ler.questionInt("Digite o ID do produto que deseja excluir: ");
//    let produto = produtos.find(prod => prod.id === id);
//    if (produto) {
//        console.log(`ID: ${produto.id} -----------------------------
//        Nome: ${produto.nome}
//        Quantidade: ${produto.quantidade}
//       Preço: ${produto.preco}
//        ------------------------------------------------
//        `);
//}
