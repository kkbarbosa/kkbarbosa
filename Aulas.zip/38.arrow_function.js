// Arrow functions Simples

function calc1(x, y) {
    return x * y;
}

let calc2 = (x, y) => { 
    return x * y;
}

let calc3 = (x, y) => x * y;

console.log(calc1(3, 4));
console.log(calc2(3, 6));
console.log(calc3(4, 7));