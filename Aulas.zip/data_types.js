// data_types Tipos de dados

let ano = 2024;
let nome = "Fulano";
let valor = 3.89;
let check = true;

console.log(ano);
console.log(typeof ano);

console.log(nome);
console.log(typeof nome);

console.log(valor);
console.log(typeof valor);

console.log(check);
console.log(typeof check);