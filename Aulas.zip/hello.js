console.log("Hello World!!");

alert("Hello World!!");

document.body.innerHTML = "Hello World"
