const ler = require('readline-sync');
const { cadPecas, listarPecas, listarPecasID, removePeca, atualizarPecas, funcaoPecas, calcularValoresID } = require('./Filhochoraemaenaove');
let autopecas = require('./Autopecas.js')

console.log(autopecas);

let check = true;
while (check) {
    console.log("-------- Sistema de Gerenciamento de Estoque --------");
    console.log("--- Escolha as Opções Abaixo. -----------------------");
    console.log("1 - Cadastrar Produto. ------------------------------");
    console.log("2 - Listar Produtos. --------------------------------");
    console.log("3 - Listar por ID. ----------------------------------");
    console.log("4 - Função da Peça. ---------------------------------");
    console.log("5 - Atualizar Peça. ---------------------------------");
    console.log("6 - Excluir Produto. --------------------------------");
    console.log("7 - Calcular todos os valores. ----------------------");
    console.log("8 - Sair. -------------------------------------------");
    console.log('-----------------------------------------------------');
let opt = ler.questionInt("=> ");

switch (opt) {
    case 1:
        cadPecas();
        break;
    case 2:
        listarPecas();
        break;
    case 3:
        listarPecasID();
        break;
    case 4:
        funcaoPecas();
        break;
    case 5:
        atualizarPecas();
        break;
    case 6:
        console.clear();
        removePeca();
        break;
    case 7:
        console.clear();
        calcularValoresID();
        break;
    case 8:
        check = false;    
        console.log("Você saiu!");
        break;
    default:
        console.log("Opção Inválida!");
}
}
