let autopecas = [
  { id: 1, nome: "Pastilha de Freio", preco: 120.90, quantidade: 15, funcao: "Freio" },
  { id: 2, nome: "Filtro de Óleo", preco: 30.99, quantidade: 25, funcao: "Filtragem de Óleo" },
  { id: 3, nome: "Supercharger", preco: 9000.80, quantidade: 2, funcao: "Aumentar Potência do Motor" },
  { id: 4, nome: "Amortecedor Dianteiro", preco: 300.74, quantidade: 10, funcao: "Absorver Impactos na Suspensão" },
  { id: 5, nome: "Bateria Automotiva", preco: 250.23, quantidade: 20, funcao: "Fornecer Energia Elétrica" },
  { id: 6, nome: "Correia Dentada", preco: 80.05, quantidade: 12, funcao: "Transmissão de Movimento" },
  { id: 7, nome: "Vela de Ignição", preco: 25.15, quantidade: 30, funcao: "Ignição da Mistura Ar/Combustível" },
  { id: 8, nome: "Sensor de Temperatura", preco: 40.40, quantidade: 18, funcao: "Medir Temperatura do Motor" },
  { id: 9, nome: "Radiador", preco: 350.70, quantidade: 8, funcao: "Resfriamento do Motor" },
  { id: 10, nome: "Embreagem", preco: 500.99, quantidade: 5, funcao: "Transferir Torque do Motor para a Transmissão" }
];
  
module.exports = autopecas;
  