const ler = require('readline-sync');
const autopecas = require('./Autopecas.js');

const cadPecas = () => {
    let i = autopecas.length;
    let id = i + 1;
    let nome = ler.question('Digite o nome da peça: ');
    let preco = ler.questionFloat('Digite o preço da peça: ');
    let quantidade = ler.questionInt('Digite a quantidade da peça: ');
    let funcao = ler.question("Qual a função da peça: ");
    addPeca(id, nome, preco, quantidade, funcao);
};

const addPeca = (id, nome, preco, quantidade, funcao) => {
    autopecas.push({id, nome ,preco, quantidade, funcao});
    console.log("Peça cadastrada com sucesso!");
    ler.question("Pressione Enter para voltar");
    console.clear();
}

const listarPecasID = () => {
    check = true;
    while(check){
        let id = ler.questionInt("Qual o ID da peça: ");
        let peca = autopecas.find(peca => peca.id === id);
        if(peca){
            console.log(
                `ID: ${peca.id}------------------------------
                Nome: ${peca.nome}
                Preço: ${peca.preco}
                Quantidade: ${peca.quantidade}
                Função: ${peca.funcao}
                ---------------------------------------------
                `);
        let opt = ler.questionInt("Deseja buscar outro produto? (1 - Sim / 2 - Não): ");
    if (opt === 1) {
        console.clear();
    } else {
        check = false;
        console.clear();
    }
    } else {
        console.log("ID não encontrado!");
}
    }
}

const listarPecas = () => {
    console.log("--------- Peças Cadastradas ---------");
    autopecas.forEach((autopecas => console.log(
        `ID: ${autopecas.id}---------------------------
        Nome: ${autopecas.nome}
        Preço: ${autopecas.preco}
        Quantidade: ${autopecas.quantidade}
        Função: ${autopecas.funcao}
        -----------------------------------------------
        `)));
}

const funcaoPecas = () => {
    check = true;
    while(check){
        let id = ler.questionInt("Qual o ID da peça: ");
        let peca = autopecas.find(peca => peca.id === id);
        if(peca){
            console.log(
                `ID: ${peca.id}------------------------------
                Nome: ${peca.nome}
                Preço: ${peca.preco}
                Quantidade: ${peca.quantidade}
                Função: ${peca.funcao}
                ---------------------------------------------
                `);
        let opt = ler.questionInt("Você quer alterar a função dessa peça? (1 - Sim / 2 - Não): ");
        if (opt === 1) {
            let funcao = ler.question("Qual a nova função da peça: ");
            peca.funcao = funcao;
            console.log("Função alterada com sucesso!");
            ler.question(".....");
            console.log("Presione Enter para voltar");
            check = false;
            console.clear();
        } else {
            check = false;
            console.clear();
  }
        } else {
    console.log("ID não encontrado!");
 }
}
}

const removePeca = () => {
    check = true;
    while(check){
        let id = ler.questionInt("Qual o ID da peça: ");
        let peca = autopecas.find((peca) => peca.id === id);
        let id_ex = autopecas.findIndex(p => p.id === id);
        if(peca){
            console.log(
                `ID: ${peca.id} -----------------------------
                Nome: ${peca.nome}
                Preço: ${peca.preco}
                Quantidade: ${peca.quantidade}
                Função: ${peca.funcao}
                ---------------------------------------------
                `);
        let opt = ler.questionInt("Deseja excluir essa peça? (1 - Sim / 2 - Não): ");
        if (opt === 1) {
            autopecas.splice(id_ex, 1);
            console.log("Peca removida!");
            console.log(".....");
            ler.question("Presione Enter para voltar.");
            check = false;
        } else {
            check = false;
            console.clear();
        }
        } else {
            console.log("ID não encontrado!");
        }
    }
}

const atualizarPecas = () => {
    check = true;
    while(check){
        let id = ler.questionInt("Qual o ID da peça que deseja atualizar: ");
        let peca = autopecas.find(peca => peca.id === id);
        if (peca) {
            console.log(
                `ID: ${peca.id}------------------------------
                Nome: ${peca.nome}
                Preço: ${peca.preco}
                Quantidade: ${peca.quantidade}
                Função: ${peca.funcao}
                ---------------------------------------------
                `);
        let opt = ler.questionInt("Deseja alterar essa peça? (1 - Sim / 2 - Não): ");
        if (opt === 1) {
            console.clear();
            attPeca(id);
            check = false;
        } else {
            console.clear();            
        }
} else {
    console.clear();
    console.log("ID não encontrado!");
}
    }
}

const attPeca = (id) => {
    let peca = autopecas.find(peca => peca.id === id);
    let pecaAtt = ler.question(`Informe o novo nome da peça: `);
    let precoAtt = ler.question(`Informe o novo preço da peça: `);
    let quantidadeAtt = ler.question(`Informe a nova quantidade da peça: `);
    let funcaoAtt = ler.question(`Informe a nova função da peça: `);
    peca.nome = pecaAtt;
    peca.preco = precoAtt;
    peca.quantidade = quantidadeAtt;
    peca.funcao = funcaoAtt;
    console.log("Peça alterada com sucesso!");
    console.log("....");
    ler.question("Pressione Enter para voltar.");
}

const calcularValoresID = () => {
    let ids = ler.question("Digite os IDs das peças separados por vírgula: ").split(',').map(id => parseInt(id));
    let condicao = peca => ids.includes(peca.id);
    somarValoresEspecificos(condicao);
  }

const somarValoresEspecificos = (condicao) => {
    let soma = 0;
    for (let i = 0; i < autopecas.length; i++) {
      if (condicao(autopecas[i])) {
        soma += autopecas[i].preco * autopecas[i].quantidade;
      }
    }
    console.log(`O valor total das peças selecionadas é: ${soma}`);
    console.log("....");
    ler.question("Pressione Enter para voltar.");
  }


module.exports = { cadPecas, addPeca, listarPecas, listarPecasID, removePeca, attPeca, atualizarPecas, funcaoPecas, calcularValoresID };
