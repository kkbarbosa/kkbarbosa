// Arrays Matriz e Objetos

let usuarios = [pessoal =[

    {nome: "Marta Silva", idade: 23, email: "martasilva@gmail.com"},
    {nome: "Danyel Sena", idade: 15, email: "danyelcomy@gmail.com"} 
],
[
    {cargo: "Gerente", salario: 4900.00},
    {cargo: "Vendedor", salario: 1300.00}

]];

//console.log(usuarios);
console.log(usuarios[0][0].nome);
console.log(usuarios[1][0].cargo);


