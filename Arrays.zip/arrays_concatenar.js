// Contactenar Arrays

let nomes = ["Marta", "Jonas", "Claudio", "José", "Geralda", "Maria"];
let outro_nomes = ["Fulano", "Ciclano", "Danyel Sena com Y"];
 
let todos = nomes.concat(outro_nomes);

console.log(todos);