// Arrays Length

let nomes = ["Marta", "Jonas", "Claudio", "José", "Geralda", "Maria"];

let x = nomes.length;

console.log(`Quantidade de nomes no array = ${x}`);