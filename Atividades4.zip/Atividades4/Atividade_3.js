// Atividade_3
const readline = require('readline-sync');

function paraKmh(ms) {
    return ms * 3.6;
}

function paraMs(kmh) {
    return kmh / 3.6;
}

const escolha = readline.question("Escolha a conversão desejada:\n1. Km/h para M/s\n2. M/s para Km/h ");

if (escolha === '1') {
    const kmh = parseFloat(readline.question("Digite a velocidade em Km/h: "));
    const ms = paraMs(kmh);
    console.log(`${kmh} Km/h equivalem a ${ms.toFixed(2)} M/s.`);
} else if (escolha === '2') {
    const ms = parseFloat(readline.question("Digite a velocidade em M/s: "));
    const kmh = paraKmh(ms);
    console.log(`${ms} M/s equivalem a ${kmh.toFixed(2)} Km/h.`); 
} else {
    console.log("Escolha inválida. Por favor, escolha 1 ou 2.");
}