// Atividade4
const ler = require("readline-sync");

let idade;

function pegarIdade() {
    idade = parseInt(ler.question("Digite a sua idade: "));
if (isNaN(idade) || idade < 0) {
    console.log("Idade invalida!!")
    return pegarIdade;
}
} 

function classificarPoridade(idade) {
    if (idade < 10) {
        console.log("Criança");
    } else if (idade <= 15) {
        console.log("Adolescente");
    } else if (idade < 50) {
        console.log("Adulto");
    } else {
        console.log("Idoso");
    }
}

pegarIdade();
classificarPoridade(idade);
