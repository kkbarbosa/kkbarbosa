// Atividade_2

const ler = require("readline-sync");

let altura = ler.question("Qual a atura do retângulo: ");
let largura = ler.question("Qual a largura do retângulo: ");

function calcularPerimetro(altura, largura) {
    var perimetro = 0;
    perimetro = 2 * parseInt(largura)  + parseInt(altura);
    return perimetro;
}

const perimetro = calcularPerimetro(altura, largura);
console.log("O perimetro do retângulo é: " + perimetro);